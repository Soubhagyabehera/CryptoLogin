Login Register
=============

These files acompany the tutorial: [Login and Registration system with PHP](https://daveismyname.blog/login-and-registration-system-with-php)
